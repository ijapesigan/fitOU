library(testthat)
library(fitOU)

test_check("fitOU")
